package com.anudip.learning;

public class Person {
    String name = "Abhinav Pawar";
    int age = 21, salary = 50000;

    public void Display() {
        System.out.println("Name : " + name);
        System.out.println("Age : " + age);
        System.out.println("Salary : " + salary);
    }
}