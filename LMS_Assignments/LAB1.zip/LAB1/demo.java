import com.anudip.learning.Person;

public class demo {
    public static void main(String[] args) {
        Person p = new Person();
        System.out.println("Test Successful..!!");
        p.Display();
    }
}
